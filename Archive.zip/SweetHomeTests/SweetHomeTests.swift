//
//  SweetHomeTests.swift
//  SweetHomeTests
//
//  Created by Lukos on 8/12/25.
//

import Testing
@testable import SweetHome

struct SweetHomeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
